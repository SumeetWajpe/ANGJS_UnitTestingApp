﻿var app = angular.module('mdl', []);
/// <reference path="mymodule.js" />
app.service('myserv', function ($http) {

    this.getData = function () {
        var result = $http.get("https://jsonplaceholder.typicode.com/posts");
        return result; //deferrer
    };

    this.get = function (id) {
        var result = $http.get("https://jsonplaceholder.typicode.com/posts/" + id);
        return result; //deferrer
    };

     
});